<template>
    <div class="col-span-12 lg:col-span-6 xl:col-span-3">
        <div class="card mb-0">
            <div class="flex justify-between items-center mb-2">
                <div>
                    <span class="block text-surface-900 dark:text-surface-0 -color mb-2 text-xl font-medium">n/a</span>
                    <div class="text-orange-400 dark:text-orange-400 font-medium ">Recent DDoS Incidents</div>
                </div>
                <div class="flex items-center justify-center bg-orange-100 dark:bg-orange-400/10 rounded-full"
                    style="width: 3rem; height: 3rem">
                    <i class="pi pi-shopping-cart text-orange-400 !text-xl"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-span-12 lg:col-span-6 xl:col-span-3">
        <div class="card mb-0">
            <div class="flex justify-between items-center mb-2">
                <div>
                    <span class="block text-surface-900 dark:text-surface-0   font-medium mb-2">____</span>
                    <div class="text-muted-color font-medium">Unhandled Abuse case</div>
                </div>
                <div class="flex items-center justify-center bg-orange-100 dark:bg-orange-400/10 rounded-full"
                    style="width: 3rem; height: 3rem">
                    <i class="pi pi-dollar text-orange-400 !text-xl"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-span-12 lg:col-span-6 xl:col-span-3">
        <div class="card mb-0">
            <div class="flex justify-between items-center mb-2">
                <div>
                    <span class="block text-surface-900 dark:text-surface-0  font-medium mb-2">____</span>
                    <div class="text-muted-color font-medium">Traffic Usage</div>
                </div>
                <div class="flex items-center justify-center bg-orange-100 dark:bg-orange-400/10 rounded-full"
                    style="width: 3rem; height: 3rem">
                    <i class="pi pi-users text-orange-400 !text-xl"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-span-12 lg:col-span-6 xl:col-span-3">
        <div class="card mb-0">
            <div class="flex justify-between items-center mb-2">
                <div>
                    <span class="block text-surface-900 dark:text-surface-0  font-medium mb-2">0 / 0</span>
                    <div class="text-orange-400 dark:text-orange-400 font-medium ">Unpaid Invoices</div>
                </div>
                <div class="flex items-center justify-center bg-orange-100 dark:bg-orange-400/10 rounded-full"
                    style="width: 3rem; height: 3rem">
                    <i class="pi pi-comment text-orange-400 !text-xl"></i>
                </div>
            </div>
        </div>
    </div>
</template>
