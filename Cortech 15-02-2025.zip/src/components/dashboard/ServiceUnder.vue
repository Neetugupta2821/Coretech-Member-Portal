<script setup>
</script>
<template>
    <div class="grid grid-cols-12 gap-8">
        <div class="col-span-12 xl:col-span-12">
            <div class="notify mb-0 bg-cyan-600/10 dark:bg-cyan-600/10 ">
                <div class="flex justify-between mb-0">
                    <div>
                        <span class="block font-medium text-cyan-500 ">
                            <i class="pi pi-exclamation-circle text-cyan-500 "></i> &nbsp;
                            Service Under Maintenance
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<style scoped>
.notify {
    padding: 10px;
    border-radius: 5px;
}
</style>
