<script setup></script>

<template>
    <div class="layout-footer">
        Copyright © 2025 <span class="text-orange-400">Core Tech</span> All right reserved.
        <!-- by -->
        <!-- <a href="https://primevue.org" target="_blank" rel="noopener noreferrer" class="text-primary font-bold hover:underline">PrimeVue</a> -->
    </div>
</template>
